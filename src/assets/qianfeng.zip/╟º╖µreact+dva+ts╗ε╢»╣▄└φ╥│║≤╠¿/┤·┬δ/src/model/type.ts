import { ILoginResponse } from "../pages/login/login.type";

export interface IGlobalState extends ILoginResponse {
}