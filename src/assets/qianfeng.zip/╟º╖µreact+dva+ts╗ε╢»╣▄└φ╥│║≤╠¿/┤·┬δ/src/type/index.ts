import { AnyAction } from "redux";

/**
 * 通用返回体
 */
export interface IBaseReponse<T> {
  /**
   * 错误码
   * 除1000外都是错误
   */
  code: number;

  /**
   * 报错信息
   */
  message: string;

  /**
   * 接口具体返回的数据
   */
  data: T;
}

/**
 * 用户角色
 */

export enum Role {
  /**
   * 用户管理角色
   */
  USERMANAGE = "userManage",

  /**
   * 活动管理角色
   */
  ACTIVITYMANAGE = "activityManage",
}

export interface IPayload<T extends Partial<AnyAction>> {
  payload: T;
}

/**
 * 分页列表的基本类型
 */
export interface IBasePagination<T> {
  /**
   * 接口返回的列表数据
   */
  list: T[];

  /**
   * 分页信息对象
   */
  pagination: {
    size: number;
    page: number;
    /**
     * 分页总数
     */
    total: number;
  };
}

/**
 * 分页参数
 */
export class BasePageParams {
  public page = 1
  public size = 3
}