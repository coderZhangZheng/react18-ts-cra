export interface IBanner {
  img: string
  id: string
}