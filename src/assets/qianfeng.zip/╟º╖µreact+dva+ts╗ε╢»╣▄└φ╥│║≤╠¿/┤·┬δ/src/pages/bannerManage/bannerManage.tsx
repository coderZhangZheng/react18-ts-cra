import { Button, Space, Table, Image, Modal, Form } from "antd";
import { ColumnsType } from "antd/lib/table";
import useFetchList from "../../hooks/use-fetch-list";
import { IBanner } from "./bannerManage.type";
import API from "./../../api";
import useDelData from "../../hooks/use-del-data";
import UploadImg from "../../components/upload-img";
import useInsert from "../../hooks/use-insert";

export default function bannerManage() {
  const [form] = Form.useForm<IBanner>();

  const { dataSource, total, filterParams, setFilterParams, getData } =
    useFetchList<IBanner>({
      API: API.getBanners,
    });
  const { ids, setIds, delData } = useDelData({
    API: API.deBanners,
    success: () => {
      setFilterParams({
        ...filterParams,
        page: 1,
      });
    },
  });

  const { handleOk, setIsModal, isModal } = useInsert({
    form,
    createData: API.createBanners,
    success: () => {
      setFilterParams({ ...filterParams, page: 1 });
    },
  });

  const columns: ColumnsType<IBanner> = [
    {
      title: "图片",
      dataIndex: "img",
      key: "id",
      render: (text) => {
        return <Image width={100} src={text} />;
      },
    },
    {
      title: "操作",
      dataIndex: "id",
      key: "id",
      render: (text, item) => {
        return (
          <Space>
            <Button danger onClick={() => delData([item.id])}>
              删除
            </Button>
          </Space>
        );
      },
    },
  ];
  return (
    <div>
      <Space>
        <Button onClick={getData}>刷新</Button>
        <Button type="primary" onClick={() => setIsModal(true)}>
          新增
        </Button>
        <Button danger onClick={() => delData()}>
          删除
        </Button>
      </Space>
      <Table
        pagination={{
          total,
          pageSize: filterParams.size,
          current: filterParams.page,
          onChange: (page) => {
            setFilterParams({
              ...filterParams,
              page,
            });
          },
        }}
        rowSelection={{
          type: "checkbox",
          onChange: (keys) => {
            setIds(keys);
          },
        }}
        columns={columns}
        dataSource={dataSource}
      ></Table>
      <Modal
        open={isModal}
        title="新增"
        onOk={handleOk}
        onCancel={() => setIsModal(false)}
      >
        <Form form={form}>
          <Form.Item label="图片" name="img">
            <UploadImg></UploadImg>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
