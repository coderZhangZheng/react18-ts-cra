import { Role } from "../../type"

/**
 * 登录传的参数
 */
export interface ILoginParams {
  username: string
  password: string
}

/**
 * 登录接口的返回值
 */
export interface ILoginResponse {
  token: string
  roles: Role[]
}