import {
  Button,
  Input,
  DatePicker,
  Image,
  Radio,
  Space,
  Table,
  Modal,
  Form,
} from "antd";
import { ColumnsType } from "antd/lib/table";
import { activityStatus } from "./activityManage.config";
import { IActivity } from "./activityManage.type";
import useFetchList from "./../../hooks/use-fetch-list";
import API from "./../../api";
import useDelData from "../../hooks/use-del-data";
import { useState } from "react";
import UploadImg from "./../../components/upload-img";
import useInsert from "../../hooks/use-insert";
import { formatDate } from "../../utils/formatDate";
import moment from "moment";

const { RangePicker } = DatePicker;

export default function activityManage() {
  const [form] = Form.useForm();

  /**
   * 调用列表hook
   * 希望拿到 列表返回的数据
   * 或者可以渲染的数据
   */
  const { dataSource, total, filterParams, setFilterParams } =
    useFetchList<IActivity>({
      API: API.getActivitys,
    });

  const { ids, setIds, delData } = useDelData({
    API: API.delActivity,
    /**
     * 删除成功
     */
    success: () => {
      /**
       * 重置分页参数
       */
      setFilterParams({ ...filterParams, page: 1 });
    },
  });

  const { handleOk, setIsModal, isModal, setDataInfo } = useInsert({
    form,
    convertData: (data) => {
      if (data.activityDate) {
        data.activityStartDate = formatDate(data.activityDate[0]);
        data.activityEndDate = formatDate(data.activityDate[1]);
      }
      return data;
    },
    createData: API.createAcityity,
    updateData: API.updateAcityity,
    success: () => {
      setFilterParams({ ...filterParams, page: 1 });
    },
    getDetail: API.getActivityDetail,
    converDetailData: (data) => {
      // 改变时间
      data.activityDate = [
        moment(data.activityStartDate, "YYYY/MM/DD"),
        moment(data.activityEndDate, "YYYY/MM/DD"),
      ];

      return data;
    },
  });

  const columns: ColumnsType<IActivity> = [
    {
      title: "活动名称",
      dataIndex: "activityName",
      key: "id",
      width: 300,
    },
    {
      title: "活动封面",
      dataIndex: "activityImg",
      key: "id",
      width: 100,
      /**
       * 第一个参数使我们dataIndex定义的值
       */
      render: (text) => {
        return <Image width={100} src={text} />;
      },
    },
    {
      title: "活动状态",
      dataIndex: "activityStatus",
      key: "id",
      width: 100,
      render: (text) => {
        return getActivityStatusName(text);
      },
    },
    {
      title: "活动上限",
      dataIndex: "activityMax",
      key: "id",
    },
    {
      title: "报名人数",
      dataIndex: "activityRegistered",
      key: "id",
    },
    {
      title: "活动时间",
      dataIndex: "activityStartDate",
      key: "id",
      render: (text, item) => {
        return `${item.activityStartDate}-${item.activityEndDate}`;
      },
    },
    {
      title: "主办方",
      dataIndex: "business",
      key: "id",
    },
    {
      title: "操作",
      dataIndex: "id",
      key: "id",
      render: (text, item) => {
        return (
          <Space>
            <Button type="primary" onClick={() => setDataInfo(item.id)}>
              编辑
            </Button>
            <Button danger onClick={() => delData([item.id])}>
              删除
            </Button>
            <Button>查看报名人数</Button>
          </Space>
        );
      },
    },
  ];

  const getActivityStatusName = (text: string) => {
    switch (text) {
      case "0":
        return "未开始";
      case "1":
        return "进行中";
      case "2":
        return "已结束";
    }
  };

  const handleCancel = () => {
    setIsModal(false);
  };

  return (
    <div>
      {/* 头部筛选栏 */}
      <Space>
        <Button>刷新</Button>
        <Button type="primary" onClick={() => setIsModal(true)}>
          新增
        </Button>
        <Button danger onClick={() => delData()}>
          删除
        </Button>
        <Radio.Group
          defaultValue=""
          onChange={(e) => {
            setFilterParams({
              ...filterParams,
              page: 1,
              activityStatus: e.target.value,
            } as any);
          }}
        >
          {activityStatus.map((item, index) => (
            <Radio.Button key={index} value={item.value}>
              {item.label}
            </Radio.Button>
          ))}
        </Radio.Group>
        <Input
          onChange={(e) => {
            setFilterParams({
              ...filterParams,
              page: 1,
              activityName: e.target.value,
            } as any);
          }}
          placeholder="请输入活动名称"
        ></Input>
      </Space>
      <Table
        columns={columns}
        dataSource={dataSource}
        style={{ marginTop: "20px" }}
        scroll={{
          x: 1500,
        }}
        rowSelection={{
          type: "checkbox",
          onChange: (keys) => {
            setIds(keys);
          },
        }}
        pagination={{
          total,
          pageSize: filterParams.size,
          current: filterParams.page,
          onChange: (page) => {
            setFilterParams({
              ...filterParams,
              page,
            });
          },
        }}
      />
      <Modal
        title="新增"
        open={isModal}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <Form form={form} labelCol={{ span: 4 }} wrapperCol={{ span: 20 }}>
          <Form.Item
            label="活动名"
            name="activityName"
            rules={[{ required: true, message: "请输入活动名" }]}
          >
            <Input></Input>
          </Form.Item>
          <Form.Item label="活动上限" name="activityMax">
            <Input></Input>
          </Form.Item>
          <Form.Item label="活动时间" name="activityDate">
            <RangePicker />
          </Form.Item>
          <Form.Item label="主办方" name="business">
            <Input></Input>
          </Form.Item>
          <Form.Item label="活动封面" name="activityImg">
            <UploadImg></UploadImg>
          </Form.Item>
          <Form.Item label="活动详情" name="activityDesc">
            <Input.TextArea />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
