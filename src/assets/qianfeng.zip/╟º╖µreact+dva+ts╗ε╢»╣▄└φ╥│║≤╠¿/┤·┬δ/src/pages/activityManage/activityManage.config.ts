export const activityStatus = [
  {
    value: "",
    label: "全部",
  },
  {
    value: "0",
    label: "未开始",
  },
  {
    value: "1",
    label: "进行中",
  },
  {
    value: "2",
    label: "已结束",
  },
];
