import dva, { DvaOption } from "dva";
import router from "./router";
import "./index.css";
import global from "./model/global";
import { IGlobalState } from "./model/type";

/**
 * 初始化dva state的方法
 * @returns
 */
const initialGLobalState = () => {
  const globalLocal = JSON.parse(localStorage.getItem("global") || "{}");

  /**
   * 首先同步现有的数据
   * 在同步localStorage里面的数据
   * 遵循后进先出原则
   */
  return {
    ...global.state,
    ...globalLocal
  };
};

const app = dva({
  /**
   * 每次state改变都会触发
   * 我们就可以每次改变的时候，存到localStorage里面
   * 在初始化的时候，在拿出来
   */
  onStateChange(state: { global: IGlobalState }) {
    localStorage.setItem("global", JSON.stringify(state.global));
  },

  initialState: {
    global: initialGLobalState(),
  },
} as unknown as DvaOption);

app.router(router);

// 引入model
app.model(global);

// 挂载并启动我们的项目
app.start("#root");
