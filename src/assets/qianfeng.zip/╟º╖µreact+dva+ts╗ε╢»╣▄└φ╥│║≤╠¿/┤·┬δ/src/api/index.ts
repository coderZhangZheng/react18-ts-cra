import { Key } from "antd/lib/table/interface";
import {
  IActivity,
  IActivityParams,
} from "../pages/activityManage/activityManage.type";
import { IBanner } from "../pages/bannerManage/bannerManage.type";
import { ILoginParams, ILoginResponse } from "../pages/login/login.type";
import {
  IUser,
  IUserParams,
} from "../pages/registerUserCheck/registerUserCheck.type";
import { BasePageParams, IBasePagination } from "../type";
import request from "./../utils/request";

/**
 * 如果业务复杂的话可以分割模块
 *
 * 现在我们可以整个api作为一层
 */
export default {
  /**
   * 登录
   */
  login(data: ILoginParams) {
    /**
     * 第一个是接受的参数类型
     * 第二个是返回的参数类型
     */
    return request.post<ILoginParams, ILoginResponse>(
      "/admin/base/open/login",
      data
    );
  },

  /**
   * 获取活动列表
   */
  getActivitys(data: IActivityParams) {
    return request.post<IActivityParams, IBasePagination<IActivity>>(
      "/admin/base/activityManage/page",
      data
    );
  },

  delActivity(ids: Key[]) {
    return request.post<Key[], {}>("/admin/base/activityManage/delete", {
      ids,
    });
  },

  getCosAutograph() {
    return request.post<{}, {}>("/admin/base/comm/cos/autograph", {});
  },

  createAcityity(data: IActivity) {
    return request.post<IActivity, {}>("/admin/base/activityManage/add", data);
  },

  updateAcityity(data: IActivity) {
    return request.post<IActivity, {}>(
      "/admin/base/activityManage/update",
      data
    );
  },

  getActivityDetail(id: string) {
    return request.get<string, IActivity>(
      `/admin/base/activityManage/info?id=${id}`
    );
  },

  getBanners(data: BasePageParams) {
    return request.post<BasePageParams, IBasePagination<IBanner>>(
      `/admin/base/banner/page`,
      data
    );
  },

  deBanners(ids: Key[]) {
    return request.post<string[], {}>(`/admin/base/banner/delete`, { ids });
  },

  createBanners(data: IBanner) {
    return request.post<IBanner, {}>(`/admin/base/banner/add`, data);
  },

  getUsers(data: IUserParams) {
    return request.post<IUserParams, IBasePagination<IUser>>(
      `/admin/base/user/page`,
      data
    );
  },

  delUser(ids: Key[]) {
    return request.post<Key[], {}>(`/admin/base/user/delete`, { ids });
  },

  checkUser(data: Pick<IUser, "checking" | "id">) {
    return request.post<Pick<IUser, "checking" | "id">, {}>(
      `/admin/base/user/update`,
      data
    );
  },

  createUser(data: IUser) {
    return request.post<IUser, {}>(`/admin/base/user/add`, data);
  },

  updateUser(data: IUser) {
    return request.post<IUser, {}>(`/admin/base/user/update`, data);
  },

  getUserDetail(id: string) {
    return request.get<string, IUser>(`/admin/base/user/info?id=${id}`);
  },
};
