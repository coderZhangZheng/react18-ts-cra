import { LoadingOutlined, PlusOutlined } from "@ant-design/icons";
import { message, Upload } from "antd";
import type { UploadChangeParam } from "antd/es/upload";
import type { RcFile, UploadFile, UploadProps } from "antd/es/upload/interface";
import React, { useState } from "react";
import { UploadRequestOption } from "rc-upload/lib/interface.d";
import API from "./../api";
import { v4 as uuidv4 } from "uuid";
import { IProps } from "./upload-img.type";

const App: React.FC = (props: IProps) => {
  const [loading, setLoading] = useState(false);
  const uploadButton = (
    <div>
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div style={{ marginTop: 8 }}>上传</div>
    </div>
  );

  const httpRequst = (req: UploadRequestOption) => {
    /**
     * 调用cos的上传图片的方法
     */
    setLoading(true);

    const cos = new COS({
      // getAuthorization 必选参数

      getAuthorization: async (options: any, callback: any) => {
        // 获取cos token
        const data: any = await API.getCosAutograph();

        const credentials = data.credentials;

        callback({
          TmpSecretId: credentials.tmpSecretId,

          TmpSecretKey: credentials.tmpSecretKey,

          SecurityToken: credentials.sessionToken,

          // 建议返回服务器时间作为签名的开始时间，避免用户浏览器本地时间偏差过大导致签名错误

          StartTime: data.startTime, // 时间戳，单位秒，如：1580000000

          ExpiredTime: data.expiredTime, // 时间戳，单位秒，如：1580000000
        });
      },
    });

    // 创建一个文件名
    const fileName = uuidv4();

    // cos 的 桶操作
    cos.putObject(
      {
        Bucket: "yn-1308768202" /* 必须 */,

        Region: "ap-shanghai" /* 存储桶所在地域，必须字段 */,

        StorageClass: "STANDARD",

        Key: fileName /* 必须 */,

        Body: req.file, // 上传文件对象
      },

      /**
       *
       * @param err 错误信息
       * @param data 请求成功返回的状态信息
       * @returns
       */
      (err: any, data: any) => {
        setLoading(false);

        if (err) {
          message.error(err);

          return;
        }

        /**
         * 我们封装的是一个表单控件类型的 上传图片组件
         * 我们希望直接可以在Form里面使用
         */
        props.onChange && props.onChange("https://" + data.Location);
      }
    );
  };

  return (
    <Upload
      name="avatar"
      listType="picture-card"
      showUploadList={false}
      customRequest={httpRequst}
    >
      {props.value ? (
        <img src={props.value} alt="avatar" style={{ width: "100%" }} />
      ) : (
        uploadButton
      )}
    </Upload>
  );
};

export default App;
