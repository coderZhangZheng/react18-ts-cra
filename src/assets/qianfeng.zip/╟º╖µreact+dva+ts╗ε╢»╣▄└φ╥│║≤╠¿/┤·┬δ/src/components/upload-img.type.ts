export interface IProps {
  onChange?: (value: string) => void
  value?: string
}