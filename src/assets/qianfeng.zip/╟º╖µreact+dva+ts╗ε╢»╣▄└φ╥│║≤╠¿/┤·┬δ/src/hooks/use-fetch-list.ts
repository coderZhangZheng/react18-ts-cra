import { useEffect, useState } from "react";
import { BasePageParams } from "../type";
import { IFetchListProps } from "./type";

/**
 * 获取列表数据的hooks
 */
export default function useFetchList<Response>(
  props: IFetchListProps<Response>
) {
  const [dataSource, setDataSource] = useState<Response[]>([]);

  const [total, setTotal] = useState(0);

  const [filterParams, setFilterParams] = useState({
    ...new BasePageParams(),
    ...(props.defaultParams || {}),
  });

  /**
   * 请求列表接口
   * 拿到对应的dataSource、total
   * 给页面传过去
   */
  useEffect(() => {
    getData();
  }, [filterParams]);

  // 获取数据
  const getData = async () => {
    const { list, pagination } = await props.API(filterParams);
    list.forEach((item: any) => {
      item.key = item.id;
    });
    setDataSource(list);
    setTotal(pagination.total);
  };

  return {
    dataSource,
    total,
    filterParams,
    setFilterParams,
    getData,
  };
}
