/**
 * 负责新增和编辑的hooks
 */

import { message } from "antd";
import { useEffect, useState } from "react";
import { IInsert } from "./type";

export default function useInsert<T>(props: IInsert<T>) {
  const [isModal, setIsModal] = useState(false);

  useEffect(() => {
    if (!isModal) {
      props.form.resetFields();
    }
  }, [isModal]);

  const handleOk = async () => {
    // 获取表单里的数据
    let data = props.form.getFieldsValue(true);
    // 对表单的数据进行转换
    data = props.convertData ? props.convertData(data) : data;
    // 调用后端接口

    // 判断是编辑还是新增
    data.id
      ? props.updateData && (await props.updateData(data))
      : props.createData && (await props.createData(data));

    // 暴露新的切面，也就是insert完成后的一个回调
    props.success && props.success();

    // 弹框提醒成功
    message.success(data.id ? "更新成功" : "创建成功");
    setIsModal(false);
  };

  /**
   * 回显表单数据的方法
   */
  const setDataInfo = async (id: string) => {
    // 获取当前id的数据
    let data = await props.getDetail!(id);
    if (props.converDetailData) {
      // 暴露出一个可以操作数据的方法
      (data as any) = props.converDetailData(data);
    }

    // 给表单回显数据
    props.form.setFieldsValue(data as any);
    // 打开弹框
    setIsModal(true);
  };

  return {
    handleOk,
    setIsModal,
    isModal,
    setDataInfo,
  };
}
