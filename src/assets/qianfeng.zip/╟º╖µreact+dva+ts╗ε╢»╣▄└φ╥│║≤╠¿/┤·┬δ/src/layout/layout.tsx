import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
} from "@ant-design/icons";
import { Button, Layout, Menu } from "antd";
import React, { useState } from "react";
import "./layout.css";
import { Route } from "dva/router";
import BannerManage from "../pages/bannerManage/bannerManage";
import ActivityManage from "../pages/activityManage/activityManage";
import RegisterUserCheck from "../pages/registerUserCheck/registerUserCheck";
import AdminUserManage from "../pages/adminUserManage/adminUserManage";
import { MenuInfo } from "rc-menu/lib/interface";
import { useHistory } from "dva";
import useLayout from "./layout.hooks";

const { Header, Sider, Content } = Layout;
const App: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const history = useHistory();

  /**
   * 拿到当前有权限的菜单
   */
  const { currentMenus } = useLayout();

  /**
   * 根据菜单获取当前路由
   * @param menuArr 
   * @returns 
   */
  const routerRender = (menuArr = currentMenus) => {
    return menuArr.map((item) => (
      <Route component={item.component} path={item.key + ""}>
        {item.children && routerRender(item.children)}
      </Route>
    ));
  };
  /**
   * 根据不同的角色显示不同的菜单
   * @param param0
   */

  const linkPage = ({ key }: MenuInfo) => {
    history.push(key);
  };

  const logout = () => {
    /**
     * token 存到了 dva里面
     * 
     * dva做了持久化，存到了localStorage里面
     * 所以退出登录的时候，只需要清空一下localStorage就可以了
     */
    localStorage.clear()
    history.push("/login");
  };

  return (
    <Layout id="layout">
      <Sider trigger={null} collapsible collapsed={collapsed}>
        <div className="logo">千锋活动管理平台</div>
        <Menu
          theme="dark"
          mode="inline"
          items={currentMenus}
          onClick={linkPage}
        />
      </Sider>
      <Layout className="site-layout">
        <Header className="site-layout-background" style={{ padding: 0 }}>
          <div className="header-box">
            {React.createElement(
              collapsed ? MenuUnfoldOutlined : MenuFoldOutlined,
              {
                className: "trigger",
                onClick: () => setCollapsed(!collapsed),
              }
            )}
            <Button className="header-btn" type="link" onClick={logout}>
              退出登录
            </Button>
          </div>
        </Header>
        <Content
          className="site-layout-background"
          style={{
            margin: "24px 16px",
            padding: 24,
            minHeight: 280,
          }}
        >
         {routerRender()}
        </Content>
      </Layout>
    </Layout>
  );
};

export default App;
