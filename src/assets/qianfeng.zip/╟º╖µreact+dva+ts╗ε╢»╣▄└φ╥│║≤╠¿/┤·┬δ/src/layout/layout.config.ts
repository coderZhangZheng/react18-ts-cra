import { Role } from "../type";
import BannerManage from "../pages/bannerManage/bannerManage";
import ActivityManage from "../pages/activityManage/activityManage";
import RegisterUserCheck from "../pages/registerUserCheck/registerUserCheck";
import AdminUserManage from "../pages/adminUserManage/adminUserManage";
import { IMenu } from "./layout.type";

/**
 * 用来存放layout页面的相关配置
 * 也就是说这个页面里面的数据 有可能后期由接口返回
 * 
 * 这里对外暴露的是一个对象，其实是一个引用数据类型
 * 应该对外暴露一个不可变数据
 * 
 * 不然 可能会出现数据错乱
 */
export const getMenus = () => [
  {
    key: "/bannerManage",
    label: "轮播图管理",
    roles: [Role.ACTIVITYMANAGE],
    component: BannerManage
  },
  {
    key: "/activityManage",
    label: "活动管理",
    roles: [Role.ACTIVITYMANAGE],
    component: ActivityManage
  },
  {
    key: "/userManage",
    label: "用户管理",
    // 父级菜单的角色一定包含子级菜单的所有角色
    roles: [Role.USERMANAGE],
    children: [
      {
        key: "/userManage/registerUserCheck",
        label: "注册用户管理",
        roles: [Role.USERMANAGE],
        component: RegisterUserCheck
      },
      {
        key: "/userManage/adminUserAdmin",
        label: "后台用户管理",
        roles: [Role.USERMANAGE],
        component: AdminUserManage
      },
    ],
  },
] as IMenu[]
